<script setup>
import NavigationItem from "./components/NavigationItem.vue";
import MapContainer from "./components/MapContainer.vue";
import IndividualItem from "./components/IndividualItem.vue";
</script>

<template>
  <main>
    <NavigationItem />
  </main>
</template>

<style>
body {
  background-color: rgb(136, 224, 170);
}
</style>
