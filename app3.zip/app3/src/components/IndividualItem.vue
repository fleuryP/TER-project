<script setup>
import MapContainer from "./MapContainer.vue";
import "ol/ol.css";
import Map from "ol/Map";
import View from "ol/View";
import TileLayer from "ol/layer/Tile";
import OSM from "ol/source/OSM";

var map = new Map({
  view: new View({
    center: [0, 0],
    zoom: 1,
  }),
  layers: [
    new TileLayer({
      source: new OSM(),
    }),
  ],
  target: "map",
});
</script>

<template>
  <main>
    <input id="individual_number" type="text" placeholder="Individual number" />
    <div id="general_bloc">
      <div id="first_bloc" class="part_bloc">
        <div id="temporal_bloc" class="bloc">
          <h3>Temporal trajectory</h3>
          <br />
          <label for="temporal"> year : </label
          ><input id="year" type="text" style="width: 50px" /><br />
          <label for="temporal"> period : </label
          ><input id="period_first" type="text" style="width: 50px" /><label
            for="temporal"
          >
            to </label
          ><input id="period_second" type="text" style="width: 50px" />
        </div>
        <div id="spatial_bloc" class="bloc">
          <h3>Spatial trajectory</h3>
          <br />
          <label for="spatial"> Country </label
          ><select name="country" id="country">
            <option value="">--Choose--</option>
            <option value="dog">Dog</option>
            <option value="cat">Cat</option></select
          ><br />
          <label for="spatial"> Departement </label
          ><select name="departement" id="departement">
            <option value="">--Choose--</option>
            <option value="dog">Dog</option>
            <option value="cat">Cat</option></select
          ><br />
          <label for="spatial"> City </label>
          <select name="city" id="city">
            <option value="">--Choose--</option>
            <option value="dog">Dog</option>
            <option value="cat">Cat</option></select
          ><br />
        </div>
        <div id="familial_bloc" class="bloc">
          <h3>Familial trajectory</h3>
          <br />
          <label for="familial"> Number of parents </label
          ><select name="number_parent" id="number_parent">
            <option value="">--Choose--</option>
            <option value="dog">1</option>
            <option value="cat">2</option></select
          ><br />
          <label for="familial"> Number of children </label
          ><select name="number_children" id="number_children">
            <option value="">--Choose--</option>
            <option value="dog">1</option>
            <option value="cat">15</option></select
          ><br />
          <label for="familial"> status </label>
          <select name="status" id="status">
            <option value="">--Choose--</option>
            <option value="dog">Married</option>
            <option value="cat">Birth child</option></select
          ><br />

          <div id="family_members">
            <div id="enfant" class="familial_specific_bloc">
              <h4>Children</h4>
              <div>
                <input
                  id="birth_children"
                  type="checkbox"
                  name="birth_children"
                  checked
                />
                <label for="birth">Birth</label>
              </div>

              <div>
                <input
                  id="work_children"
                  type="checkbox"
                  name="work_children"
                  checked
                />
                <label for="work">Work</label>
              </div>
              <div>
                <input
                  type="checkbox"
                  id="res_children"
                  name="res_children"
                  checked
                />
                <label for="children_res">Res</label><br />
                <label for="enfant"> Rank </label>
                <select name="rank_children" id="rank_children">
                  <option value="">--Choose--</option>
                  <option value="dog">1</option>
                  <option value="cat">15</option></select
                ><br />
              </div>
            </div>
            <div id="parent" class="familial_specific_bloc">
              <h4>Parents</h4>
              <div>
                <input
                  type="checkbox"
                  id="birth_parent"
                  name="birth_parent"
                  checked
                />
                <label for="birth">Birth</label>
              </div>
              <div>
                <input
                  type="checkbox"
                  id="work_parent"
                  name="work_parent"
                  checked
                />
                <label for="work">Work</label>
              </div>
              <div>
                <input
                  type="checkbox"
                  id="res_parent"
                  name="res_parent"
                  checked
                />
                <label for="res">Res</label>
              </div>
              <label for="parent"> Rank </label>
              <select name="rank_parent" id="rank_parent">
                <option value="">--Choose--</option>
                <option value="dog">1</option>
                <option value="cat">2</option></select
              ><br />
            </div>
            <div id="conjoint" class="familial_specific_bloc">
              <h4>Conjoint</h4>
              <div>
                <input
                  type="checkbox"
                  name="birth_cjt"
                  id="birth_cjt"
                  checked
                />
                <label for="scales">Birth</label>
              </div>

              <div>
                <input type="checkbox" id="work_cjt" name="work_cjt" checked />
                <label for="horns">Work</label>
              </div>
              <div>
                <input type="checkbox" id="res_cjt" name="res_cjt" checked />
                <label for="horns">Res</label>
              </div>
              <div>
                <label for="horns"></label>
              </div>
            </div>
          </div>
        </div>
        <div id="residential_bloc" class="bloc">
          <h3>Residential trajectory</h3>
          <br />
          <label for="residential"> Rank </label>
          <select name="pets" id="residential_rank">
            <option value="">--Choose--</option>
            <option value="dog">Dog</option>
            <option value="cat">Cat</option></select
          ><br />
        </div>
        <div id="professionnal_bloc" class="bloc">
          <h3>Professionnal trajectory</h3>
          <br />

          <label for="professionnal"> Activity </label
          ><select name="activity" id="activity">
            <option value="">--Choose--</option>
            <option value="dog">Dog</option>
            <option value="cat">Cat</option></select
          ><br />
          <label for="spatial"> Rank </label>
          <select name="professionnal_rank" id="professionnal_rank">
            <option value="">--Choose--</option>
            <option value="dog">Dog</option>
            <option value="cat">Cat</option></select
          ><br />
        </div>
        <div id="leisure_bloc" class="bloc">
          <h3>Leisure trajectory</h3>
          <br />
          <label for="spatial"> Rank </label>
          <select name="leisure_rank" id="leisure_rank">
            <option value="">--Choose--</option>
            <option value="dog">Dog</option>
            <option value="cat">Cat</option></select
          ><br />
        </div>
      </div>

      <div id="second_bloc" class="part_bloc">
        <div id="map_container">
          <component :is="MapContainer" />
        </div>
        <div>
          <h4>Lignes de vie de l'individu XXXX</h4>
          <br />
        </div>
      </div>
    </div>
  </main>
</template>

<style>
.bloc {
  background-color: rgb(168, 219, 148);
  height: auto;
  margin: 2px;
  padding: 10px 24px; /* Some padding */
  border: 2px solid rgb(39, 107, 39); /* Green border */
}
#general_bloc {
  display: flex;
}
#map_container {
  width: 100%;
  height: 100%;
  background-color: rgb(50, 84, 53);
  padding: 1%;
  border-radius: 2%;
}

main {
  margin-top: 2%;
}

label {
  display: inline-block;
  width: 110px;
}
select {
  padding: 5px 10px;
}
.familial_specific_bloc {
  display: inline-block;
}

.part_bloc {
  width: 600px;
  height: 600px;
  flex: 1;
  padding: 1em;
}
</style>
