<script setup>
import GroupItem from "./GroupItem.vue";
import IndividualItem from "./IndividualItem.vue";
import MetaItem from "./MetaItem.vue";
</script>

<template>
  <header>
    <div id="header" class="btn-group" style="width: 100%">
      <button id="individual_window" style="width: 25%">Individu</button>
      <button id="group_window" style="width: 25%">Groupe</button>
      <button id="meta_window" style="width: 25%">Meta-données</button>
      <button id="?_window" style="width: 25%">?</button>
    </div>
  </header>
  <main>
    <IndividualItem />
  </main>
</template>

<style>
.btn-group button {
  background-color: #04aa6d; /* Green background */
  border: 1px solid green; /* Green border */
  color: white; /* White text */
  padding: 10px 24px; /* Some padding */
  cursor: pointer; /* Pointer/hand icon */
  float: left; /* Float the buttons side by side */
}

.btn-group button:not(:last-child) {
  border-right: none; /* Prevent double borders */
}

/* Clear floats (clearfix hack) */
.btn-group:after {
  content: "";
  clear: both;
  display: table;
}

/* Add a background color on hover */
.btn-group button:hover {
  background-color: #3e8e41;
}
</style>
